package sss.isspassesandroid;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import android.support.v4.app.ActivityCompat;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;


public class MainActivity extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback, LocationListener {

    // Globals

    private Context mContext = null;

    protected LocationManager locationManager;

    private String outPasses = null;

    private ListView listView;

    private JSONObject jsonPasses;
    private JSONArray jsonPassesArray;

    public ArrayAdapter<String> adapter;

    public ArrayList<String> values = new ArrayList<>(10);


    // Mirrors

    private TextView txtMessage;
    private TextView txtPasses;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mContext = getApplicationContext();

        // Attach the mirror UI controls
        txtMessage = (TextView) findViewById(R.id.txtMessage);
        txtMessage.setText("Waiting for signal...");
        //txtPasses = (TextView) findViewById(R.id.txtPasses);
        listView = (ListView) findViewById(R.id.list);

        // Data adapter
        // Define a new Adapter
        // First parameter - Context
        // Second parameter - Layout for the row
        // Third parameter - ID of the TextView to which the data is written
        // Forth - the Array of data

        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                values);

        // Attach adapter to ListView
        listView.setAdapter(adapter);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        //********************************
        // Check for location permission
        //********************************

        boolean permissionGranted =
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;

        if (permissionGranted) {
            // Put up quick message indicating it's active.
            Toast.makeText(getApplicationContext(),
                    "Location permissions have been granted.",
                    Toast.LENGTH_SHORT).show();

            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    0,
                    0,
                    this);
        } else {
            // Put up message saying permission needed.
            Toast.makeText(getApplicationContext(),
                    "Location permissions need to be requested.",
                    Toast.LENGTH_SHORT).show();
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 200);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 200: {
                if(grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    System.out.println(">>> LOCATION PERMISSION GRANTED SUCCESSFULLY");
                }
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        /*
        if (id == R.id.action_settings) {
            return true;
        }
        */
        return super.onOptionsItemSelected(item);
    }


    //********************************
    // Location methods interface
    //********************************

    @Override
    public void onLocationChanged(Location location) {
        //txtLat = (TextView) findViewById(R.id.textview1);

        DecimalFormat coordFormat = new DecimalFormat("###0.0000000");

        final String strLat = coordFormat.format(location.getLatitude());
        final String strLon = coordFormat.format(location.getLongitude());

        System.out.println(">>> Latitude: " + strLat + ", Longitude: " + strLon);

        txtMessage.setText("Latitude:" + strLat + ", Longitude:" + strLon);

        try {

            adapter.notifyDataSetChanged();

            Thread thread = new Thread(new Runnable() {

                @Override
                public void run() {
                    try  {
                        String serviceUrl = "http://api.open-notify.org/iss-pass.json?lat=" + strLat + "&lon=" + strLon;
                        System.out.println(">>> callHttpUrlConnectionAction called");

                        // JSON returned here
                        outPasses = callHttpUrlConnectionAction(serviceUrl);
                        System.out.println(">>> outPasses = ");
                        System.out.println(outPasses);

                        try {

                            jsonPasses = new JSONObject(outPasses);
                            jsonPassesArray = jsonPasses.getJSONArray("response");

                            values.clear();
                            //values = new ArrayList<>(jsonPassesArray.length());
                            //values = new String[jsonPassesArray.length()];          // we do know the length

                            for (Integer n = 0; n < jsonPassesArray.length(); n++) {
                                Integer intDuration = jsonPassesArray.getJSONObject(n).getInt("duration");
                                Long longRiseTime = jsonPassesArray.getJSONObject(n).getLong("risetime");
                                System.out.println(">>> OBJECT NO. = " + n.toString());
                                System.out.println(">>>    DURATION = " + intDuration.toString());
                                System.out.println(">>>    RISE TIME = " + longRiseTime.toString());

                                // Format the pass for display
                                Integer n1 = n + 1;
                                String outInfo = n1.toString() + ". " +
                                        "Duration: " + durationToMinsSecs(intDuration) + "\n" +
                                        "Rise Time: " + riseTimeToString(longRiseTime);
                                //values[n] = outInfo;
                                values.add(outInfo);
                                System.out.println(">>> added: outInfo = " + outInfo);

                            }

                            // see if this refreshes
                            System.out.println(">>> values.size() = " + values.size());
                            System.out.println(">>> trying to refresh");

                            //adapter.notifyDataSetChanged();

                        } catch (Exception ex) {
                            System.out.println(">>> JSON conversion failed: " + ex.getStackTrace());
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            thread.start();

        } catch (java.lang.Exception e) {
            System.out.println(">>> Failure on callHttpUrlConnectionAction");
        }
    }

    @Override
    public void onProviderDisabled(String provider) {
        txtMessage.setText(">>> Disabled");
        System.out.println(">>> disabled");
    }

    @Override
    public void onProviderEnabled(String provider) {
        //txtMessage.setText(">>> Enabled");
        System.out.println(">>> enabled");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        //txtMessage.setText(">>> Status Changed");
        System.out.println(">>> status");
    }

    private String durationToMinsSecs(Integer totalsecs) {

        String result = null;

        Integer mins = totalsecs / 60;
        Integer secs = totalsecs - (mins * 60);

        result = mins.toString() + "m, " + secs.toString() + "s";

        return result;

    }

    private String riseTimeToString(Long unixSeconds) {

        String result = null;

        // convert seconds to milliseconds
        Date date = new Date(unixSeconds*1000L);

        // the format of your date
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdf2 = new SimpleDateFormat("H:mm:ss");

        // give a timezone reference for formatting (see comment at the bottom)
        sdf1.setTimeZone(TimeZone.getTimeZone("GMT-6"));
        sdf2.setTimeZone(TimeZone.getTimeZone("GMT-6"));
        result = sdf1.format(date) + " at " + sdf2.format(date) + " CST";

        return result;

    }


    //************************************
    // Volley HTTP request
    //************************************

    public String callHttpUrlConnectionAction(String desiredUrl)
            throws Exception
    {
        URL url = null;
        BufferedReader reader = null;
        StringBuilder stringBuilder;

        try
        {
            // create the HttpURLConnection
            url = new URL(desiredUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // just want to do an HTTP GET here
            connection.setRequestMethod("GET");

            // give it 15 seconds to respond
            connection.setReadTimeout(15*1000);
            connection.connect();

            // read the output from the server
            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            stringBuilder = new StringBuilder();

            String line = null;
            while ((line = reader.readLine()) != null)
            {
                stringBuilder.append(line + "\n");
            }
            return stringBuilder.toString();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally
        {
            // close the reader; this can throw an exception too, so
            // wrap it in another try/catch block.
            if (reader != null)
            {
                try
                {
                    reader.close();
                }
                catch (IOException ioe)
                {
                    ioe.printStackTrace();
                }
            }
        }
    }

}
